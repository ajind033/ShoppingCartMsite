import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import {Routes, RouterModule} from '@angular/router';

import {QuantityService} from './quantity.service';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { FooterComponent } from './footer/footer.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [{
  path:'',
  component:HomeComponent
},{
  path:'cart',
  component:CartComponent
},{  
  path:'check',
  component:CheckoutComponent
},{
  path:'**',
  component:PageNotFoundComponent
}]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    CartComponent,
    CheckoutComponent,
    FooterComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,    
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [QuantityService],
  bootstrap: [AppComponent]
})
export class AppModule { }
