export class Product {
    name:string;
    category:string;
    mrp:number;
}
